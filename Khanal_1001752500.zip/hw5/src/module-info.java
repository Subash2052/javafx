//Subash Khanal
module HW5 {
    requires javafx.fxml;
    requires javafx.controls;

    opens sample;
}